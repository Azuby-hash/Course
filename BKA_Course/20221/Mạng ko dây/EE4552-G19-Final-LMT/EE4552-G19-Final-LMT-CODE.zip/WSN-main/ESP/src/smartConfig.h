#ifndef _SMART_CONFIG
#define _SMART_CONFIG

#include "WiFi.h"

extern String server;
extern String serverPassword;

void wifiSmartConfig();

#endif