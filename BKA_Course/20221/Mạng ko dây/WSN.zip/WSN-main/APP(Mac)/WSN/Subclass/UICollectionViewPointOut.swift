//
//  UICollectionViewPointOut.swift
//  AIArtGenerator2.0
//
//  Created by Tap Dev5 on 01/12/2022.
//

import UIKit

class UICollectionViewPointOut: UICollectionView {

    override func point(inside point: CGPoint, with event: UIEvent?) -> Bool {
        return true
    }

}
