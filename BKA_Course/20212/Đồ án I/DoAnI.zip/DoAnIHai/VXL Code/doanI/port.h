#ifndef _PORT_H_
#define _PORT_H_

// Khai bao k�t noi LCD
sbit LCD_RS	= P2^0;
sbit LCD_EN	= P2^1;
sbit LCD_D4	= P2^4;
sbit LCD_D5 = P2^5;
sbit LCD_D6 = P2^6;
sbit LCD_D7 = P2^7;

#endif