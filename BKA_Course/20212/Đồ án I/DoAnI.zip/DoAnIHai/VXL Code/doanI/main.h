#ifndef _MAIN_H_
#define _MAIN_H_

#include <regx52.h>
#define FREQ_OSC 12000000
#define BAUD_RATE 9600

#endif