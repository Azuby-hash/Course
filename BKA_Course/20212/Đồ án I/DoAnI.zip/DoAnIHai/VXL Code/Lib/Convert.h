#ifndef _CONVERT_H_
#define _CONVERT_H_

void Byte2Str(unsigned char input, char * output);
void Short2Str(char input, char * output);
void Word2Str(unsigned int input, char * output);
void Int2Str(int input, char * output);

#endif