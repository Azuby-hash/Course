// Yeu cau: Khai bao ket noi voi ADC0804
//#define ADC0804_DATA	P2
//sbit ADC0804_CS = P3^0;
//sbit ADC0804_RD = P3^1;
//sbit ADC0804_WR = P3^2;
//sbit ADC0804_INTR = P3^3;

#ifndef _ADC0804_H_
#define _ADC0804_H_

unsigned char ADC0804_Read();

#endif