#ifndef _DELAY_H_
#define _DELAY_H_

void Delay_ms(unsigned int t);

#endif