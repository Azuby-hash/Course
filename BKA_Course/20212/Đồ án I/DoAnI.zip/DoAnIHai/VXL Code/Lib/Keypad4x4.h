#ifndef _KEYPAD4X4_H_
#define _KEYPAD4X4_H_

unsigned char KeyPress();

#endif